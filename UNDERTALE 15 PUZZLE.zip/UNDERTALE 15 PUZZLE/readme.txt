
NICHOLAS YESU 
WEB PROGRAMMING 2019


Description: This is a 15 Puzzle Challenge themed around Undertale an Indie video game made in 2016. You are given an image to try and recreate with a time limit of 2 minutes. To start press the shuffle button. Once time is up you will be alerted that you are done. The amount of moves are youR points, the less points you have the better you did.



Just press shuffle to start as soon as you come on the screen. This will allow you to get ample amount of time because the timer starts immediately. Proceed to solve the puzzle in as little moves as possible.
